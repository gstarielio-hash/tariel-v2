// ==========================================
// TARIEL.IA — REVISOR_PAINEL_MESA.JS
// Papel: operação da mesa e pacote técnico no painel do revisor.
// ==========================================

(function () {
    "use strict";

    const NS = window.TarielRevisorPainel;
    if (!NS || NS.__mesaWired__) return;
    NS.__mesaWired__ = true;

    const {
        tokenCsrf,
        els,
        state,
        escapeHtml,
        nl2br,
        formatarDataHora,
        normalizarAnexoMensagem,
        renderizarAnexosMensagem,
        showStatus,
        resumoMensagem,
        normalizarCollaborationSummary,
        downloadJson,
        obterPacoteMesaLaudo,
        atualizarIndicadoresListaLaudo,
        openModal,
        ehAbortError,
        obterContextoLaudoAtivo,
        contextoLaudoAindaValido,
        userCapabilityEnabled,
        tenantCapabilityReason,
        sincronizarPlaceholderContextoMesa,
        medirSync,
        medirAsync,
        snapshotDOM
    } = NS;

    const obterItemKindMesa = (item) => {
        const valor = String(item?.item_kind || "").trim().toLowerCase();
        if (valor === "pendency" || valor === "whisper" || valor === "message") {
            return valor;
        }
        const tipoLegacy = String(item?.tipo || "").trim().toLowerCase();
        if (tipoLegacy === "humano_eng") return "pendency";
        if (tipoLegacy === "humano_insp") return "whisper";
        return "message";
    };

    const obterPendencyStateMesa = (item) => {
        const valor = String(item?.pendency_state || "").trim().toLowerCase();
        if (valor === "open" || valor === "resolved" || valor === "not_applicable") {
            return valor;
        }
        if (obterItemKindMesa(item) !== "pendency") {
            return "not_applicable";
        }
        return String(item?.resolvida_em || "").trim() ? "resolved" : "open";
    };

    const resolverTipoOperacaoMesa = (item, tipo) => {
        if (tipo === "whisper") return "whisper";
        if (tipo === "resolvida") return "resolvida";
        if (tipo === "aberta") return "aberta";
        const itemKind = obterItemKindMesa(item);
        if (itemKind === "whisper") return "whisper";
        return obterPendencyStateMesa(item) === "resolved" ? "resolvida" : "aberta";
    };

    const renderizarItemOperacaoMesa = (item, { tipo = "aberta", permitirResponder = false } = {}) => {
        const tipoResolvido = resolverTipoOperacaoMesa(item, tipo);
        const mensagemId = Number(item?.id || 0);
        const referenciaId = Number(item?.referencia_mensagem_id || 0);
        const dataBase = tipoResolvido === "resolvida" ? item?.resolvida_em : item?.criado_em;
        const dataLabel = formatarDataHora(dataBase || item?.criado_em);
        const anexos = Array.isArray(item?.anexos) ? item.anexos.map(normalizarAnexoMensagem).filter(Boolean) : [];
        const texto = resumoMensagem(item?.texto || (anexos.length ? "Anexo enviado" : ""));
        const resolvedorNome = String(item?.resolvida_por_nome || "").trim();
        const titulo = tipoResolvido === "whisper"
            ? `Chamado #${mensagemId || "-"}`
            : `Mensagem #${mensagemId || "-"}`;
        const chipTexto = tipoResolvido === "resolvida"
            ? "Resolvida"
            : tipoResolvido === "whisper"
                ? "Chamado"
                : "Aberta";
        const subtitulo = tipoResolvido === "resolvida"
            ? `Resolvida em ${escapeHtml(dataLabel)}`
            : `Criada em ${escapeHtml(dataLabel)}`;
        const contextoBotao = referenciaId > 0
            ? `
                <button type="button" class="btn-mesa-acao" data-mesa-action="timeline-ref" data-ref-id="${referenciaId}">
                    <span class="material-symbols-rounded" aria-hidden="true">format_quote</span>
                    <span>Ver contexto</span>
                </button>
            `
            : "";
        const responderBotao = permitirResponder && mensagemId > 0
            ? `
                <button type="button" class="btn-mesa-acao" data-mesa-action="responder-item" data-msg-id="${mensagemId}">
                    <span class="material-symbols-rounded" aria-hidden="true">reply</span>
                    <span>Responder</span>
                </button>
            `
            : "";
        const botaoPendencia = mensagemId > 0 && tipoResolvido !== "whisper"
            ? `
                <button
                    type="button"
                    class="btn-mesa-acao"
                    data-mesa-action="alternar-pendencia"
                    data-msg-id="${mensagemId}"
                    data-proxima-lida="${tipoResolvido === "aberta" ? "true" : "false"}"
                >
                    <span class="material-symbols-rounded" aria-hidden="true">${tipoResolvido === "aberta" ? "task_alt" : "restart_alt"}</span>
                    <span>${tipoResolvido === "aberta" ? "Marcar resolvida" : "Reabrir"}</span>
                </button>
            `
            : "";

        return `
            <li class="mesa-operacao-item ${escapeHtml(tipoResolvido)}">
                <div class="mesa-operacao-item-topo">
                    <strong>${escapeHtml(titulo)}</strong>
                    <span class="mesa-operacao-chip ${escapeHtml(tipoResolvido)}">${escapeHtml(chipTexto)}</span>
                </div>
                <p>${escapeHtml(texto)}</p>
                ${renderizarAnexosMensagem(anexos)}
                <div class="mesa-operacao-meta">
                    <span>${subtitulo}</span>
                    ${referenciaId > 0 ? `<span>Ref. #${escapeHtml(String(referenciaId))}</span>` : "<span>Sem referência explícita</span>"}
                    ${tipoResolvido === "resolvida" && resolvedorNome ? `<span>Resolvida por ${escapeHtml(resolvedorNome)}</span>` : ""}
                </div>
                <div class="mesa-operacao-acoes">
                    <button type="button" class="btn-mesa-acao" data-mesa-action="timeline-msg" data-msg-id="${mensagemId}">
                        <span class="material-symbols-rounded" aria-hidden="true">forum</span>
                        <span>Ir para historico</span>
                    </button>
                    ${contextoBotao}
                    ${botaoPendencia}
                    ${responderBotao}
                </div>
            </li>
        `;
    };

    const renderizarColunaOperacaoMesa = ({
        titulo,
        itens = [],
        tipo = "aberta",
        mensagemVazia,
        permitirResponder = false
    }) => {
        const lista = Array.isArray(itens) ? itens : [];
        const corpo = lista.length
            ? `
                <ul class="mesa-operacao-lista">
                    ${lista.slice(0, 5).map((item) => renderizarItemOperacaoMesa(item, { tipo, permitirResponder })).join("")}
                </ul>
            `
            : `<p class="mesa-operacao-vazio">${escapeHtml(mensagemVazia || "Sem registros no momento.")}</p>`;

        return `
            <section class="mesa-operacao-coluna">
                <header>
                    <h4>${escapeHtml(titulo)}</h4>
                    <span class="mesa-operacao-contagem">${escapeHtml(String(lista.length))}</span>
                </header>
                ${corpo}
            </section>
        `;
    };

    const humanizarSlugMesaOperacional = (value) => {
        const text = String(value || "").trim().replace(/_/g, " ");
        if (!text) return "";
        return text.replace(/\b\w/g, (match) => match.toUpperCase());
    };

    const COVERAGE_STATUS_LABELS = {
        accepted: "Aceita",
        irregular: "Irregular",
        missing: "Faltando",
        collected: "Coletada",
        pending: "Pendente"
    };

    const COVERAGE_KIND_LABELS = {
        image_slot: "Imagem obrigatoria",
        gate_requirement: "Gate operacional",
        structured_form: "Formulario",
        normative_item: "Item normativo",
        gate: "Gate"
    };

    const IRREGULARITY_TYPE_LABELS = {
        field_reopened: "Campo reaberto",
        block_returned_to_inspector: "Bloco devolvido ao inspetor"
    };

    const IRREGULARITY_STATUS_LABELS = {
        open: "Aberta",
        acknowledged: "Reconhecida",
        resolved: "Resolvida",
        dismissed: "Descartada"
    };

    const OPERATIONAL_STATUS_LABELS = {
        ok: "OK operacional",
        irregular: "Irregular",
        replaced: "Substituida",
        pending: "Pendente"
    };

    const MESA_STATUS_LABELS = {
        accepted: "Aceita pela Mesa",
        rejected: "Rejeitada pela Mesa",
        needs_recheck: "Revalidar",
        not_reviewed: "Nao revisada"
    };

    const BLOCK_REVIEW_STATUS_LABELS = {
        returned: "Devolvido",
        attention: "Atencao",
        partial: "Parcial",
        ready: "Pronto",
        empty: "Vazio"
    };

    const rotuloCoverageStatus = (status) =>
        COVERAGE_STATUS_LABELS[String(status || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(status || "pending");

    const rotuloCoverageKind = (kind) =>
        COVERAGE_KIND_LABELS[String(kind || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(kind || "item");

    const rotuloOperationalStatus = (status) =>
        OPERATIONAL_STATUS_LABELS[String(status || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(status || "pending");

    const rotuloMesaStatus = (status) =>
        MESA_STATUS_LABELS[String(status || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(status || "not_reviewed");

    const rotuloRevisaoBlocoStatus = (status) =>
        BLOCK_REVIEW_STATUS_LABELS[String(status || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(status || "empty");

    const rotuloTipoDiffHistorico = (status) => {
        const normalized = String(status || "").trim().toLowerCase();
        if (normalized === "added") return "Novo";
        if (normalized === "removed") return "Removido";
        return "Alterado";
    };

    const rotuloTrailStatus = (status) => {
        const normalized = String(status || "").trim().toLowerCase();
        if (normalized === "ready") return "Pronto";
        if (normalized === "attention") return "Atencao";
        if (normalized === "blocked") return "Bloqueado";
        return humanizarSlugMesaOperacional(status || "status");
    };

    const renderizarRevisaoPorBlocoMesa = (reviewByBlock) => {
        if (!reviewByBlock || typeof reviewByBlock !== "object") {
            return `
                <section class="mesa-operacao-card mesa-operacao-card--block-review">
                    <header>
                        <div>
                            <h4>Revisão por seção</h4>
                            <p>Sem leitura consolidada por bloco para este laudo ainda.</p>
                        </div>
                    </header>
                    <p class="mesa-operacao-vazio">A revisão por seção aparece quando o documento do caso e o contexto operacional já podem ser comparados.</p>
                </section>
            `;
        }

        const items = Array.isArray(reviewByBlock.items) ? reviewByBlock.items.slice(0, 8) : [];
        const body = items.length
            ? `
                <ul class="mesa-operacao-coverage-lista">
                    ${items.map((item) => {
                        const status = String(item?.review_status || "empty").trim().toLowerCase();
                        const meta = [
                            `Documento: ${humanizarSlugMesaOperacional(item?.document_status || "empty")}`,
                            `${Number(item?.filled_fields || 0)}/${Number(item?.total_fields || 0)} campos`,
                            Number(item?.coverage_total || 0) > 0 ? `${Number(item.coverage_total)} evidência(s) relacionadas` : "",
                            Number(item?.coverage_alert_count || 0) > 0 ? `${Number(item.coverage_alert_count)} alerta(s)` : "",
                            Number(item?.open_pendency_count || 0) > 0 ? `${Number(item.open_pendency_count)} pendencia(s)` : "",
                            Number(item?.open_return_count || 0) > 0 ? `${Number(item.open_return_count)} refazer(es)` : ""
                        ].filter(Boolean).join(" | ");
                        const detalhes = [
                            item?.summary || "",
                            item?.diff_short ? `Destaque: ${item.diff_short}` : "",
                            item?.latest_return_at ? `Ultimo retorno: ${formatarDataHora(item.latest_return_at)}` : "",
                            item?.recommended_action ? `Acao: ${item.recommended_action}` : ""
                        ].filter(Boolean).join(" | ");
                        return `
                            <li class="mesa-operacao-coverage-item ${escapeHtml(status)}">
                                <div class="mesa-operacao-item-topo">
                                    <strong>${escapeHtml(String(item?.title || "Bloco"))}</strong>
                                    <span class="mesa-operacao-chip ${escapeHtml(status)}">${escapeHtml(rotuloRevisaoBlocoStatus(status))}</span>
                                </div>
                                ${meta ? `<p>${escapeHtml(meta)}</p>` : ""}
                                ${detalhes ? `<div class="mesa-operacao-meta"><span>${escapeHtml(detalhes)}</span></div>` : ""}
                            </li>
                        `;
                    }).join("")}
                </ul>
            `
            : '<p class="mesa-operacao-vazio">Nenhum bloco relevante foi materializado para revisao.</p>';

        return `
            <section class="mesa-operacao-card mesa-operacao-card--block-review">
                <header>
                    <div>
                        <h4>Revisão por seção</h4>
                        <p>Leitura operacional das seções do laudo, cruzando documento, evidências e devoluções ao campo.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Blocos</span>
                        <strong>${escapeHtml(String(reviewByBlock.total_blocks || 0))}</strong>
                    </article>
                    <article>
                        <span>Prontos</span>
                        <strong>${escapeHtml(String(reviewByBlock.ready_blocks || 0))}</strong>
                    </article>
                    <article>
                        <span>Atencao</span>
                        <strong>${escapeHtml(String(reviewByBlock.attention_blocks || 0))}</strong>
                    </article>
                    <article>
                        <span>Devolvidos</span>
                        <strong>${escapeHtml(String(reviewByBlock.returned_blocks || 0))}</strong>
                    </article>
                </div>
                ${body}
            </section>
        `;
    };

    const rotuloIrregularityType = (type) =>
        IRREGULARITY_TYPE_LABELS[String(type || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(type || "irregularidade");

    const rotuloIrregularityStatus = (status) =>
        IRREGULARITY_STATUS_LABELS[String(status || "").trim().toLowerCase()] || humanizarSlugMesaOperacional(status || "open");

    const renderizarCoverageMapMesa = (coverageMap) => {
        if (!coverageMap || typeof coverageMap !== "object") {
            return `
                <section class="mesa-operacao-card mesa-operacao-card--coverage">
                    <header>
                        <div>
                            <h4>Checklist de evidências</h4>
                            <p>Sem estrutura de evidências calculada para este laudo.</p>
                        </div>
                    </header>
                    <p class="mesa-operacao-vazio">Este checklist aparece quando o caso já tem evidências rastreáveis o bastante para revisão.</p>
                </section>
            `;
        }

        const items = Array.isArray(coverageMap.items) ? coverageMap.items.slice(0, 6) : [];
        const validationMode = String(coverageMap.final_validation_mode || "").trim();
        const body = items.length
            ? `
                <ul class="mesa-operacao-coverage-lista">
                    ${items.map((item) => {
                        const status = String(item?.status || "pending").trim().toLowerCase();
                        const requiredTag = item?.required
                            ? '<span class="mesa-operacao-inline-tag">Obrigatoria</span>'
                            : '<span class="mesa-operacao-inline-tag neutra">Opcional</span>';
                        const meta = [
                            rotuloCoverageKind(item?.kind),
                            item?.component_type ? `Componente: ${item.component_type}` : "",
                            item?.view_angle ? `Angulo: ${item.view_angle}` : "",
                            item?.quality_score !== null && item?.quality_score !== undefined ? `Qualidade ${item.quality_score}` : "",
                            item?.coherence_score !== null && item?.coherence_score !== undefined ? `Coerencia ${item.coherence_score}` : "",
                            item?.operational_status ? rotuloOperationalStatus(item.operational_status) : "",
                            item?.mesa_status ? rotuloMesaStatus(item.mesa_status) : ""
                        ].filter(Boolean).join(" | ");
                        const detalhes = [
                            item?.summary || "",
                            Array.isArray(item?.failure_reasons) && item.failure_reasons.length
                                ? `Alertas: ${item.failure_reasons.join(", ")}`
                                : "",
                            item?.replacement_evidence_key ? `Substituicao: ${item.replacement_evidence_key}` : ""
                        ].filter(Boolean).join(" | ");
                        const botaoRefazer = status !== "accepted"
                            ? `
                                <div class="mesa-operacao-item-acoes">
                                    <button
                                        type="button"
                                        class="btn-mesa-acao"
                                        data-mesa-action="solicitar-refazer-coverage"
                                        data-evidence-key="${escapeHtml(String(item?.evidence_key || ""))}"
                                        data-title="${escapeHtml(String(item?.title || "Item de cobertura"))}"
                                        data-kind="${escapeHtml(String(item?.kind || "coverage_item"))}"
                                        data-required="${item?.required ? "true" : "false"}"
                                        data-source-status="${escapeHtml(String(item?.source_status || ""))}"
                                        data-operational-status="${escapeHtml(String(item?.operational_status || ""))}"
                                        data-mesa-status="${escapeHtml(String(item?.mesa_status || ""))}"
                                        data-component-type="${escapeHtml(String(item?.component_type || ""))}"
                                        data-view-angle="${escapeHtml(String(item?.view_angle || ""))}"
                                        data-summary="${escapeHtml(String(item?.summary || ""))}"
                                        data-failure-reasons="${escapeHtml(encodeURIComponent(JSON.stringify(Array.isArray(item?.failure_reasons) ? item.failure_reasons : [])))}"
                                    >
                                        <span class="material-symbols-rounded" aria-hidden="true">assignment_return</span>
                                        <span>Solicitar ajuste ao inspetor</span>
                                    </button>
                                </div>
                            `
                            : "";
                        return `
                            <li class="mesa-operacao-coverage-item ${escapeHtml(status)}">
                                <div class="mesa-operacao-item-topo">
                                    <strong>${escapeHtml(String(item?.title || "Cobertura"))}</strong>
                                    <span class="mesa-operacao-chip ${escapeHtml(status)}">${escapeHtml(rotuloCoverageStatus(status))}</span>
                                </div>
                                <div class="mesa-operacao-inline-tags">
                                    ${requiredTag}
                                    ${validationMode ? `<span class="mesa-operacao-inline-tag">${escapeHtml(validationMode)}</span>` : ""}
                                </div>
                                ${meta ? `<p>${escapeHtml(meta)}</p>` : ""}
                                ${detalhes ? `<div class="mesa-operacao-meta"><span>${escapeHtml(detalhes)}</span></div>` : ""}
                                ${botaoRefazer}
                            </li>
                        `;
                    }).join("")}
                </ul>
            `
            : '<p class="mesa-operacao-vazio">Nenhum item de cobertura materializado para este laudo.</p>';

        return `
            <section class="mesa-operacao-card mesa-operacao-card--coverage">
                <header>
                    <div>
                        <h4>Checklist de evidências</h4>
                        <p>O que este caso exige, o que já foi coletado e o que ainda trava a aprovação.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Obrigatorias</span>
                        <strong>${escapeHtml(String(coverageMap.total_required || 0))}</strong>
                    </article>
                    <article>
                        <span>Coletadas</span>
                        <strong>${escapeHtml(String(coverageMap.total_collected || 0))}</strong>
                    </article>
                    <article>
                        <span>Aceitas</span>
                        <strong>${escapeHtml(String(coverageMap.total_accepted || 0))}</strong>
                    </article>
                    <article>
                        <span>Alertas</span>
                        <strong>${escapeHtml(String((coverageMap.total_missing || 0) + (coverageMap.total_irregular || 0)))}</strong>
                    </article>
                </div>
                ${body}
            </section>
        `;
    };

    const renderizarHistoricoInspecaoMesa = (history) => {
        if (!history || typeof history !== "object") {
            return `
                <section class="mesa-operacao-card">
                    <header>
                        <div>
                            <h4>Histórico de Inspeção</h4>
                            <p>Sem base aprovada anterior compatível para esta família ainda.</p>
                        </div>
                    </header>
                    <p class="mesa-operacao-vazio">O clone e o diff entre emissões aparecem quando já existe pelo menos um caso aprovado da mesma família.</p>
                </section>
            `;
        }

        const diff = history.diff && typeof history.diff === "object" ? history.diff : {};
        const highlights = Array.isArray(diff.highlights) ? diff.highlights.slice(0, 4) : [];
        const identityHighlights = Array.isArray(diff.identity_highlights) ? diff.identity_highlights.slice(0, 4) : [];
        const blockHighlights = Array.isArray(diff.block_highlights) ? diff.block_highlights.slice(0, 3) : [];
        const diffCounters = [
            { label: "Mudanças", value: diff.changed_count || 0, tone: "attention" },
            { label: "Novos", value: diff.added_count || 0, tone: "accepted" },
            { label: "Removidos", value: diff.removed_count || 0, tone: "returned" },
        ].filter((item) => Number(item.value || 0) > 0);
        return `
            <section class="mesa-operacao-card">
                <header>
                    <div>
                        <h4>Histórico de Inspeção</h4>
                        <p>Comparação com a última inspeção aprovada compatível com este caso.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Base anterior</span>
                        <strong>${escapeHtml(String(history.source_codigo_hash || history.source_laudo_id || "-"))}</strong>
                    </article>
                    <article>
                        <span>Match</span>
                        <strong>${escapeHtml(humanizarSlugMesaOperacional(history.matched_by || "family_recency"))}</strong>
                    </article>
                    <article>
                        <span>Clone seguro</span>
                        <strong>${escapeHtml(String(history.prefilled_field_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Diff</span>
                        <strong>${escapeHtml(String(diff.total_changes || (diff.changed_count || 0) + (diff.added_count || 0) + (diff.removed_count || 0)))}</strong>
                    </article>
                </div>
                ${diff.summary ? `<p>${escapeHtml(String(diff.summary || ""))}</p>` : ""}
                ${history.approved_at ? `<div class="mesa-operacao-meta"><span>Base aprovada em ${escapeHtml(formatarDataHora(history.approved_at))}</span></div>` : ""}
                ${diffCounters.length ? `
                    <div class="mesa-operacao-inline-tags">
                        ${diffCounters.map((item) => `
                            <span class="mesa-operacao-inline-tag ${escapeHtml(String(item.tone || "neutra"))}">
                                ${escapeHtml(String(item.label || "Diff"))}: ${escapeHtml(String(item.value || 0))}
                            </span>
                        `).join("")}
                    </div>
                ` : ""}
                ${blockHighlights.length ? `
                    <div class="mesa-operacao-inline-lists">
                        <div>
                            <strong>Blocos alterados</strong>
                            <ul class="mesa-operacao-coverage-lista mesa-operacao-diff-lista">
                                ${blockHighlights.map((item) => `
                                    <li class="mesa-operacao-coverage-item attention mesa-operacao-diff-item">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(String(item?.title || "Bloco"))}</strong>
                                            <span class="mesa-operacao-chip attention">${escapeHtml(String(item?.total_changes || 0))} delta(s)</span>
                                        </div>
                                        ${item?.summary ? `<p>${escapeHtml(String(item.summary))}</p>` : ""}
                                        <div class="mesa-operacao-inline-tags">
                                            <span class="mesa-operacao-inline-tag attention">Alterados: ${escapeHtml(String(item?.changed_count || 0))}</span>
                                            ${Number(item?.added_count || 0) > 0 ? `<span class="mesa-operacao-inline-tag accepted">Novos: ${escapeHtml(String(item.added_count || 0))}</span>` : ""}
                                            ${Number(item?.removed_count || 0) > 0 ? `<span class="mesa-operacao-inline-tag returned">Removidos: ${escapeHtml(String(item.removed_count || 0))}</span>` : ""}
                                            ${Number(item?.identity_change_count || 0) > 0 ? `<span class="mesa-operacao-inline-tag">Criticos: ${escapeHtml(String(item.identity_change_count || 0))}</span>` : ""}
                                        </div>
                                        ${Array.isArray(item?.fields) && item.fields.length ? `
                                            <div class="mesa-operacao-diff-fields">
                                                ${item.fields.slice(0, 3).map((field) => `
                                                    <article>
                                                        <span>${escapeHtml(rotuloTipoDiffHistorico(field?.change_type || "changed"))}</span>
                                                        <strong>${escapeHtml(String(field?.label || "Campo"))}</strong>
                                                        <p>${escapeHtml(String(field?.previous_value || "vazio"))} → ${escapeHtml(String(field?.current_value || "vazio"))}</p>
                                                    </article>
                                                `).join("")}
                                            </div>
                                        ` : ""}
                                    </li>
                                `).join("")}
                            </ul>
                        </div>
                    </div>
                ` : ""}
                ${identityHighlights.length ? `
                    <div class="mesa-operacao-inline-lists">
                        <div>
                            <strong>Campos críticos</strong>
                            <ul class="mesa-operacao-coverage-lista mesa-operacao-diff-lista">
                                ${identityHighlights.map((item) => `
                                    <li class="mesa-operacao-coverage-item attention mesa-operacao-diff-item ${escapeHtml(String(item?.change_type || "changed"))}">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(String(item?.label || "Campo"))}</strong>
                                            <span class="mesa-operacao-chip attention">${escapeHtml(rotuloTipoDiffHistorico(item?.change_type || "changed"))}</span>
                                        </div>
                                        <div class="mesa-operacao-meta">
                                            <span>${escapeHtml(String(item?.path || ""))}</span>
                                        </div>
                                        <div class="mesa-operacao-diff-values">
                                            <article>
                                                <span>Antes</span>
                                                <strong>${escapeHtml(String(item?.previous_value || "vazio"))}</strong>
                                            </article>
                                            <article>
                                                <span>Agora</span>
                                                <strong>${escapeHtml(String(item?.current_value || "vazio"))}</strong>
                                            </article>
                                        </div>
                                    </li>
                                `).join("")}
                            </ul>
                        </div>
                    </div>
                ` : ""}
                ${!blockHighlights.length && !identityHighlights.length && highlights.length ? `
                    <ul class="mesa-operacao-coverage-lista mesa-operacao-diff-lista">
                        ${highlights.map((item) => `
                            <li class="mesa-operacao-coverage-item attention mesa-operacao-diff-item ${escapeHtml(String(item?.change_type || "changed"))}">
                                <div class="mesa-operacao-item-topo">
                                    <strong>${escapeHtml(String(item?.label || "Campo"))}</strong>
                                    <span class="mesa-operacao-chip attention">${escapeHtml(rotuloTipoDiffHistorico(item?.change_type || "changed"))}</span>
                                </div>
                                <div class="mesa-operacao-meta">
                                    <span>${escapeHtml(String(item?.path || ""))}</span>
                                </div>
                                <div class="mesa-operacao-diff-values">
                                    <article>
                                        <span>Antes</span>
                                        <strong>${escapeHtml(String(item?.previous_value || "vazio"))}</strong>
                                    </article>
                                    <article>
                                        <span>Agora</span>
                                        <strong>${escapeHtml(String(item?.current_value || "vazio"))}</strong>
                                    </article>
                                </div>
                            </li>
                        `).join("")}
                    </ul>
                ` : (!blockHighlights.length && !identityHighlights.length ? '<p class="mesa-operacao-vazio">Sem diferenças estáveis relevantes em relação à base aprovada anterior.</p>' : "")}
            </section>
        `;
    };

    const renderizarVerificacaoPublicaMesa = (verification) => {
        if (!verification || typeof verification !== "object") {
            return "";
        }
        const verificationUrl = String(verification.verification_url || "");
        const qrImageDataUri = String(verification.qr_image_data_uri || "");
        const statusVisualLabel = String(
            verification.status_visual_label || verification.status_revisao || "-"
        ).trim() || "-";
        return `
            <section class="mesa-operacao-card">
                <header>
                    <div>
                        <h4>Verificação Pública</h4>
                        <p>Hash público e link oficial para conferência documental.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Hash</span>
                        <strong>${escapeHtml(String(verification.hash_short || verification.codigo_hash || "-"))}</strong>
                    </article>
                    <article>
                        <span>Fluxo</span>
                        <strong>${escapeHtml(statusVisualLabel)}</strong>
                    </article>
                    <article>
                        <span>Conformidade</span>
                        <strong>${escapeHtml(String(verification.status_conformidade || "-"))}</strong>
                    </article>
                    <article>
                        <span>Outcome</span>
                        <strong>${escapeHtml(String(verification.document_outcome || "-"))}</strong>
                    </article>
                </div>
                <div class="mesa-operacao-verification-shell">
                    ${qrImageDataUri ? `<img class="mesa-operacao-verification-qr" src="${escapeHtml(qrImageDataUri)}" alt="QR Code de verificacao publica" />` : ""}
                    <div class="mesa-operacao-verification-copy">
                        <div class="mesa-operacao-meta">
                            <span>${escapeHtml(verificationUrl)}</span>
                        </div>
                        ${verificationUrl ? `<a class="mesa-operacao-link" href="${escapeHtml(verificationUrl)}" target="_blank" rel="noopener noreferrer">Abrir verificação pública</a>` : ""}
                    </div>
                </div>
            </section>
        `;
    };

    const renderizarHistoricoRefazerInspetor = (historico) => {
        const itens = Array.isArray(historico) ? historico.slice(0, 6) : [];
        const body = itens.length
            ? `
                <ul class="mesa-operacao-coverage-lista">
                    ${itens.map((item) => {
                        const status = String(item?.status || "open").trim().toLowerCase();
                        const meta = [
                            item?.block_key ? `Bloco: ${humanizarSlugMesaOperacional(item.block_key)}` : "",
                            item?.evidence_key ? `Evidencia: ${item.evidence_key}` : "",
                            item?.detected_by_user_name ? `Por ${item.detected_by_user_name}` : "",
                            `Detectada em ${formatarDataHora(item?.detected_at)}`
                        ].filter(Boolean).join(" | ");
                        const resolucao = [
                            item?.resolution_mode ? humanizarSlugMesaOperacional(item.resolution_mode) : "",
                            item?.resolved_by_user_name ? `por ${item.resolved_by_user_name}` : "",
                            item?.resolved_at ? formatarDataHora(item.resolved_at) : ""
                        ].filter(Boolean).join(" ");
                        return `
                            <li class="mesa-operacao-coverage-item ${escapeHtml(status)}">
                                <div class="mesa-operacao-item-topo">
                                    <strong>${escapeHtml(rotuloIrregularityType(item?.irregularity_type))}</strong>
                                    <span class="mesa-operacao-chip ${escapeHtml(status)}">${escapeHtml(rotuloIrregularityStatus(status))}</span>
                                </div>
                                ${item?.summary ? `<p>${escapeHtml(String(item.summary))}</p>` : ""}
                                <div class="mesa-operacao-meta">
                                    ${meta ? `<span>${escapeHtml(meta)}</span>` : ""}
                                    ${resolucao ? `<span>Resolucao: ${escapeHtml(resolucao)}</span>` : ""}
                                    ${item?.resolution_notes ? `<span>${escapeHtml(String(item.resolution_notes))}</span>` : ""}
                                </div>
                            </li>
                        `;
                    }).join("")}
                </ul>
            `
            : '<p class="mesa-operacao-vazio">Nenhum refazer do inspetor foi registrado para este laudo.</p>';

        return `
            <section class="mesa-operacao-card mesa-operacao-card--history">
                <header>
                    <div>
                        <h4>Refazer Inspetor</h4>
                        <p>Historico rastreavel de reaberturas e devolucoes para campo.</p>
                    </div>
                </header>
                ${body}
            </section>
        `;
    };

    const renderizarMemoriaOperacionalFamilia = (memory) => {
        if (!memory || typeof memory !== "object") {
            return `
                <section class="mesa-operacao-card mesa-operacao-card--memory">
                    <header>
                        <div>
                            <h4>Memoria da Familia</h4>
                            <p>Sem memoria consolidada para esta familia ainda.</p>
                        </div>
                    </header>
                    <p class="mesa-operacao-vazio">Os snapshots aprovados e os eventos operacionais passam a fortalecer esta base conforme a operacao cresce.</p>
                </section>
            `;
        }

        const topEvents = Array.isArray(memory.top_event_types) ? memory.top_event_types.slice(0, 4) : [];
        const topIrregularities = Array.isArray(memory.top_open_irregularities) ? memory.top_open_irregularities.slice(0, 4) : [];
        return `
            <section class="mesa-operacao-card mesa-operacao-card--memory">
                <header>
                    <div>
                        <h4>Memoria da Familia</h4>
                        <p>${escapeHtml(humanizarSlugMesaOperacional(memory.family_key || ""))}</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Snapshots aprovados</span>
                        <strong>${escapeHtml(String(memory.approved_snapshot_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Eventos</span>
                        <strong>${escapeHtml(String(memory.operational_event_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Evidencias validadas</span>
                        <strong>${escapeHtml(String(memory.validated_evidence_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Irregularidades abertas</span>
                        <strong>${escapeHtml(String(memory.open_irregularity_count || 0))}</strong>
                    </article>
                </div>
                <div class="mesa-operacao-meta">
                    <span>Ultima aprovacao: ${escapeHtml(formatarDataHora(memory.latest_approved_at))}</span>
                    <span>Ultimo evento: ${escapeHtml(formatarDataHora(memory.latest_event_at))}</span>
                </div>
                <div class="mesa-operacao-inline-lists">
                    <div>
                        <strong>Top eventos</strong>
                        ${topEvents.length
                            ? `<div class="mesa-operacao-inline-tags">${topEvents.map((item) => `<span class="mesa-operacao-inline-tag">${escapeHtml(`${humanizarSlugMesaOperacional(item.item_key)} (${item.count})`)}</span>`).join("")}</div>`
                            : '<p class="mesa-operacao-vazio">Sem eventos recorrentes suficientes.</p>'}
                    </div>
                    <div>
                        <strong>Top abertas</strong>
                        ${topIrregularities.length
                            ? `<div class="mesa-operacao-inline-tags">${topIrregularities.map((item) => `<span class="mesa-operacao-inline-tag alerta">${escapeHtml(`${humanizarSlugMesaOperacional(item.item_key)} (${item.count})`)}</span>`).join("")}</div>`
                            : '<p class="mesa-operacao-vazio">Nenhuma irregularidade aberta recorrente.</p>'}
                    </div>
                </div>
            </section>
        `;
    };

    const renderizarAnexoPackMesa = (annexPack) => {
        if (!annexPack || typeof annexPack !== "object") {
            return "";
        }
        const items = Array.isArray(annexPack.items) ? annexPack.items.slice(0, 6) : [];
        return `
            <section class="mesa-operacao-card mesa-operacao-card--coverage">
                <header>
                    <div>
                        <h4>Anexo Pack</h4>
                        <p>Pacote de anexos e artefatos exigidos para a emissão oficial.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Itens</span>
                        <strong>${escapeHtml(String(annexPack.total_items || 0))}</strong>
                    </article>
                    <article>
                        <span>Obrigatórios</span>
                        <strong>${escapeHtml(String(annexPack.total_required || 0))}</strong>
                    </article>
                    <article>
                        <span>Presentes</span>
                        <strong>${escapeHtml(String(annexPack.total_present || 0))}</strong>
                    </article>
                    <article>
                        <span>Pendentes</span>
                        <strong>${escapeHtml(String(annexPack.missing_required_count || 0))}</strong>
                    </article>
                </div>
                ${Array.isArray(annexPack.missing_items) && annexPack.missing_items.length ? `
                    <div class="mesa-operacao-inline-tags">
                        ${annexPack.missing_items.slice(0, 4).map((item) => `
                            <span class="mesa-operacao-inline-tag alerta">${escapeHtml(String(item || ""))}</span>
                        `).join("")}
                    </div>
                ` : ""}
                ${items.length ? `
                    <ul class="mesa-operacao-coverage-lista">
                        ${items.map((item) => {
                            const status = item?.present ? "accepted" : "missing";
                            const meta = [
                                humanizarSlugMesaOperacional(item?.category || "anexo"),
                                item?.required ? "Obrigatório" : "Opcional",
                                item?.source ? humanizarSlugMesaOperacional(item.source) : ""
                            ].filter(Boolean).join(" | ");
                            return `
                                <li class="mesa-operacao-coverage-item ${escapeHtml(status)}">
                                    <div class="mesa-operacao-item-topo">
                                        <strong>${escapeHtml(String(item?.label || "Anexo"))}</strong>
                                        <span class="mesa-operacao-chip ${escapeHtml(status)}">${escapeHtml(item?.present ? "Pronto" : "Pendente")}</span>
                                    </div>
                                    ${meta ? `<p>${escapeHtml(meta)}</p>` : ""}
                                    ${item?.summary ? `<div class="mesa-operacao-meta"><span>${escapeHtml(String(item.summary))}</span></div>` : ""}
                                </li>
                            `;
                        }).join("")}
                    </ul>
                ` : '<p class="mesa-operacao-vazio">Sem anexos materializados para este laudo ainda.</p>'}
            </section>
        `;
    };

    const resumirHashSha256Mesa = (value, limite = 12) => {
        const texto = String(value || "").trim();
        return texto ? `${texto.slice(0, limite)}...` : "";
    };

    const construirResumoIntegridadePdfOficialMesa = (currentIssue) => {
        if (!currentIssue || typeof currentIssue !== "object") {
            return null;
        }

        const comparisonStatus = String(currentIssue.primary_pdf_comparison_status || "").trim().toLowerCase();
        const diverged = !!currentIssue.primary_pdf_diverged || comparisonStatus === "diverged";
        const frozenVersion = String(currentIssue.primary_pdf_storage_version || "").trim();
        const currentVersion = String(currentIssue.current_primary_pdf_storage_version || "").trim();
        const frozenHash = resumirHashSha256Mesa(currentIssue.primary_pdf_sha256);
        const currentHash = resumirHashSha256Mesa(currentIssue.current_primary_pdf_sha256);
        const meta = [];

        if (frozenVersion) {
            meta.push(`Emitido ${frozenVersion}`);
        }
        if (currentVersion && currentVersion !== frozenVersion) {
            meta.push(`Atual ${currentVersion}`);
        }
        if (frozenHash) {
            meta.push(`Congelado ${frozenHash}`);
        }
        if (currentHash && diverged) {
            meta.push(`Atual ${currentHash}`);
        }

        if (diverged) {
            return {
                title: "Integridade do PDF principal",
                summary: "O PDF atual do caso divergiu do PDF congelado na emissão oficial.",
                chip: "Reemitir",
                tone: "returned",
                meta,
            };
        }

        if (!frozenVersion && !frozenHash && !currentVersion && !currentHash) {
            return null;
        }

        return {
            title: "Integridade do PDF principal",
            summary: "O PDF principal atual continua compatível com a emissão oficial congelada.",
            chip: "Íntegro",
            tone: "accepted",
            meta,
        };
    };

    const renderizarEmissaoOficialMesa = (officialIssue) => {
        if (!officialIssue || typeof officialIssue !== "object") {
            return "";
        }
        const blockers = Array.isArray(officialIssue.blockers) ? officialIssue.blockers.slice(0, 4) : [];
        const signatories = Array.isArray(officialIssue.signatories) ? officialIssue.signatories.slice(0, 4) : [];
        const eligibleSignatories = signatories.filter((item) => ["ready", "expiring_soon"].includes(String(item?.status || "").trim().toLowerCase()));
        const auditTrail = Array.isArray(officialIssue.audit_trail) ? officialIssue.audit_trail.slice(0, 5) : [];
        const currentIssue = officialIssue.current_issue && typeof officialIssue.current_issue === "object"
            ? officialIssue.current_issue
            : null;
        const reissueOriginNumber = String(currentIssue?.reissue_of_issue_number || "").trim();
        const reissueReasonSummary = String(currentIssue?.reissue_reason_summary || "").trim();
        const documentIntegrity = construirResumoIntegridadePdfOficialMesa(currentIssue);
        const reissueRecommended = !!officialIssue.reissue_recommended;
        const genericReissueWarning = reissueRecommended && (!documentIntegrity || documentIntegrity.tone !== "returned")
            ? {
                title: "Reemissão recomendada",
                summary: "A emissão oficial segue registrada, mas a governança recomenda emitir um novo pacote antes da próxima entrega pública.",
                chip: "Atenção",
                tone: "attention",
                meta: [],
            }
            : null;
        const tone = officialIssue.ready_for_issue ? "accepted" : blockers.length ? "returned" : "attention";
        return `
            <section class="mesa-operacao-card mesa-operacao-card--memory">
                <header>
                    <div>
                        <h4>Emissão Oficial</h4>
                        <p>${escapeHtml(String(officialIssue.issue_status_label || "Governança documental"))}</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Status</span>
                        <strong>${escapeHtml(String(officialIssue.issue_status || "-"))}</strong>
                    </article>
                    <article>
                        <span>Compatíveis</span>
                        <strong>${escapeHtml(String(officialIssue.compatible_signatory_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Elegíveis</span>
                        <strong>${escapeHtml(String(officialIssue.eligible_signatory_count || 0))}</strong>
                    </article>
                    <article>
                        <span>Bloqueios</span>
                        <strong>${escapeHtml(String(officialIssue.blocker_count || 0))}</strong>
                    </article>
                </div>
                <div class="mesa-operacao-inline-tags">
                    <span class="mesa-operacao-inline-tag ${escapeHtml(tone)}">${escapeHtml(String(officialIssue.signature_status_label || "Sem leitura de assinatura"))}</span>
                    ${officialIssue.verification_url ? `<span class="mesa-operacao-inline-tag">${escapeHtml(String(officialIssue.verification_url))}</span>` : ""}
                    ${documentIntegrity && documentIntegrity.tone === "returned"
                        ? '<span class="mesa-operacao-inline-tag returned">PDF emitido divergente</span>'
                        : ""}
                    ${genericReissueWarning ? '<span class="mesa-operacao-inline-tag attention">Reemissão recomendada</span>' : ""}
                    <span class="mesa-operacao-inline-tag neutra">ZIP com manifesto e hash SHA-256</span>
                </div>
                ${currentIssue ? `
                    <div class="mesa-operacao-inline-lists">
                        <div>
                            <strong>Emissão congelada</strong>
                            <ul class="mesa-operacao-coverage-lista">
                                <li class="mesa-operacao-coverage-item accepted">
                                    <div class="mesa-operacao-item-topo">
                                        <strong>${escapeHtml(String(currentIssue.issue_number || "Emissão oficial"))}</strong>
                                        <span class="mesa-operacao-chip accepted">${escapeHtml(String(currentIssue.issue_state_label || "Emitido"))}</span>
                                    </div>
                                    <p>${escapeHtml(String(currentIssue.signatory_name || "Signatário não informado"))}${currentIssue.signatory_registration ? ` · ${escapeHtml(String(currentIssue.signatory_registration))}` : ""}</p>
                                    <div class="mesa-operacao-meta">
                                        ${currentIssue.issued_at ? `<span>${escapeHtml(formatarDataHora(currentIssue.issued_at))}</span>` : ""}
                                        ${currentIssue.package_sha256 ? `<span>SHA-256 ${escapeHtml(String(currentIssue.package_sha256).slice(0, 16))}...</span>` : ""}
                                    </div>
                                </li>
                                ${documentIntegrity ? `
                                    <li class="mesa-operacao-coverage-item ${escapeHtml(documentIntegrity.tone)}">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(documentIntegrity.title)}</strong>
                                            <span class="mesa-operacao-chip ${escapeHtml(documentIntegrity.tone)}">${escapeHtml(documentIntegrity.chip)}</span>
                                        </div>
                                        <p>${escapeHtml(documentIntegrity.summary)}</p>
                                        ${documentIntegrity.meta.length ? `
                                            <div class="mesa-operacao-meta">
                                                ${documentIntegrity.meta.map((item) => `<span>${escapeHtml(String(item))}</span>`).join("")}
                                            </div>
                                        ` : ""}
                                    </li>
                                ` : ""}
                                ${reissueOriginNumber || reissueReasonSummary ? `
                                    <li class="mesa-operacao-coverage-item accepted">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>Linhagem da emissão</strong>
                                            <span class="mesa-operacao-chip accepted">Reemitido</span>
                                        </div>
                                        <p>${escapeHtml(
                                            reissueOriginNumber
                                                ? `Esta emissão substitui ${reissueOriginNumber}.`
                                                : "Esta emissão substitui uma emissão oficial anterior."
                                        )}</p>
                                        ${reissueReasonSummary ? `
                                            <div class="mesa-operacao-meta">
                                                <span>${escapeHtml(reissueReasonSummary)}</span>
                                            </div>
                                        ` : ""}
                                    </li>
                                ` : ""}
                                ${genericReissueWarning ? `
                                    <li class="mesa-operacao-coverage-item ${escapeHtml(genericReissueWarning.tone)}">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(genericReissueWarning.title)}</strong>
                                            <span class="mesa-operacao-chip ${escapeHtml(genericReissueWarning.tone)}">${escapeHtml(genericReissueWarning.chip)}</span>
                                        </div>
                                        <p>${escapeHtml(genericReissueWarning.summary)}</p>
                                    </li>
                                ` : ""}
                            </ul>
                        </div>
                    </div>
                ` : ""}
                ${blockers.length ? `
                    <ul class="mesa-operacao-coverage-lista">
                        ${blockers.map((item) => `
                            <li class="mesa-operacao-coverage-item returned">
                                <div class="mesa-operacao-item-topo">
                                    <strong>${escapeHtml(String(item?.title || "Bloqueio"))}</strong>
                                    <span class="mesa-operacao-chip returned">${escapeHtml(item?.blocking ? "Bloqueante" : "Aviso")}</span>
                                </div>
                                ${item?.message ? `<p>${escapeHtml(String(item.message))}</p>` : ""}
                            </li>
                        `).join("")}
                    </ul>
                ` : '<p class="mesa-operacao-vazio">Sem bloqueios adicionais. A emissão oficial pode seguir.</p>'}
                ${auditTrail.length ? `
                    <div class="mesa-operacao-inline-lists">
                        <div>
                            <strong>Trilha documental</strong>
                            <ul class="mesa-operacao-coverage-lista mesa-operacao-trail-lista">
                                ${auditTrail.map((item) => `
                                    <li class="mesa-operacao-coverage-item ${escapeHtml(String(item?.status || "attention"))}">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(String(item?.title || "Evento documental"))}</strong>
                                            <span class="mesa-operacao-chip ${escapeHtml(String(item?.status || "attention"))}">
                                                ${escapeHtml(rotuloTrailStatus(item?.status || "attention"))}
                                            </span>
                                        </div>
                                        ${item?.summary ? `<p>${escapeHtml(String(item.summary))}</p>` : ""}
                                        <div class="mesa-operacao-meta">
                                            ${item?.recorded_at ? `<span>${escapeHtml(formatarDataHora(item.recorded_at))}</span>` : ""}
                                            <span>${item?.blocking ? "Bloqueante" : "Rastreavel"}</span>
                                        </div>
                                    </li>
                                `).join("")}
                            </ul>
                        </div>
                    </div>
                ` : ""}
                ${signatories.length ? `
                    <div class="mesa-operacao-inline-lists">
                        <div>
                            <strong>Signatários governados</strong>
                            <div class="mesa-operacao-inline-tags">
                                ${signatories.map((item) => `
                                    <span class="mesa-operacao-inline-tag ${escapeHtml(String(item?.status || "attention"))}">
                                        ${escapeHtml(`${String(item?.nome || "Signatário")} · ${String(item?.funcao || "")}`)}
                                    </span>
                                `).join("")}
                            </div>
                        </div>
                    </div>
                ` : ""}
                ${(officialIssue.issue_action_enabled && eligibleSignatories.length) || (currentIssue && currentIssue.package_storage_ready) ? `
                    <div class="mesa-operacao-action-rail">
                        ${userCapabilityEnabled("reviewer_issue") ? eligibleSignatories.map((item) => `
                            <button
                                type="button"
                                class="mesa-operacao-inline-tag mesa-operacao-inline-tag--button"
                                data-mesa-action="emitir-oficialmente"
                                data-signatory-id="${escapeHtml(String(item?.id || ""))}"
                                data-signatory-name="${escapeHtml(String(item?.nome || "Signatário"))}"
                                data-current-issue-id="${escapeHtml(String(currentIssue?.id || ""))}"
                                data-current-issue-number="${escapeHtml(String(currentIssue?.issue_number || ""))}"
                            >
                                ${escapeHtml(String(officialIssue.issue_action_label || "Emitir oficialmente"))} · ${escapeHtml(String(item?.nome || "Signatário"))}
                            </button>
                        `).join("") : `
                            <button
                                type="button"
                                class="mesa-operacao-inline-tag mesa-operacao-inline-tag--button"
                                disabled
                                aria-disabled="true"
                                title="${escapeHtml(tenantCapabilityReason("reviewer_issue"))}"
                            >
                                Emissão oficial governada
                            </button>
                        `}
                        ${currentIssue && currentIssue.package_storage_ready && userCapabilityEnabled("reviewer_issue") ? `
                            <button
                                type="button"
                                class="mesa-operacao-inline-tag mesa-operacao-inline-tag--button"
                                data-mesa-action="baixar-emissao-oficial"
                            >
                                Baixar bundle emitido
                            </button>
                        ` : ""}
                    </div>
                ` : ""}
            </section>
        `;
    };

    const renderizarGovernancaPolicyMesa = (policySummary) => {
        if (!policySummary || typeof policySummary !== "object") {
            return "";
        }

        const entitlements = (
            policySummary.tenant_entitlements && typeof policySummary.tenant_entitlements === "object"
                ? policySummary.tenant_entitlements
                : {}
        );
        const familyPolicy = (
            policySummary.family_policy_summary && typeof policySummary.family_policy_summary === "object"
                ? policySummary.family_policy_summary
                : {}
        );
        const redFlags = Array.isArray(policySummary.red_flags) ? policySummary.red_flags.slice(0, 4) : [];
        const allowedModes = Array.isArray(entitlements.allowed_review_modes)
            ? entitlements.allowed_review_modes
            : [];

        return `
            <section class="mesa-operacao-card mesa-operacao-card--policy">
                <header>
                    <div>
                        <h4>Governança da Revisão</h4>
                        <p>Modo efetivo, liberacao da empresa e alertas que endurecem a decisao.</p>
                    </div>
                </header>
                <div class="mesa-operacao-card-kpis">
                    <article>
                        <span>Modo</span>
                        <strong>${escapeHtml(humanizarSlugMesaOperacional(policySummary.review_mode || "mesa_required"))}</strong>
                    </article>
                    <article>
                        <span>Plano</span>
                        <strong>${escapeHtml(String(entitlements.plan_name || "n/d"))}</strong>
                    </article>
                    <article>
                        <span>Release</span>
                        <strong>${escapeHtml(String(familyPolicy.release_status || "sem release"))}</strong>
                    </article>
                    <article>
                        <span>Red flags</span>
                        <strong>${escapeHtml(String(redFlags.length))}</strong>
                    </article>
                </div>
                <div class="mesa-operacao-meta">
                    ${entitlements.usage_status ? `<span>Uso da empresa: ${escapeHtml(String(entitlements.usage_status))}</span>` : ""}
                    ${allowedModes.length
                        ? `<span>Modos liberados: ${escapeHtml(allowedModes.map((item) => humanizarSlugMesaOperacional(item)).join(", "))}</span>`
                        : ""}
                </div>
                ${redFlags.length
                    ? `
                        <ul class="mesa-operacao-coverage-lista">
                            ${redFlags.map((item) => {
                                const severity = String(item?.severity || "high").trim().toLowerCase();
                                const tone = severity === "critical" || severity === "high" ? "irregular" : "missing";
                                return `
                                    <li class="mesa-operacao-coverage-item ${escapeHtml(tone)}">
                                        <div class="mesa-operacao-item-topo">
                                            <strong>${escapeHtml(String(item?.title || "Red flag"))}</strong>
                                            <span class="mesa-operacao-chip ${escapeHtml(tone)}">${escapeHtml(humanizarSlugMesaOperacional(severity))}</span>
                                        </div>
                                        ${item?.message ? `<p>${escapeHtml(String(item.message))}</p>` : ""}
                                        <div class="mesa-operacao-meta">
                                            ${item?.source ? `<span>Fonte: ${escapeHtml(humanizarSlugMesaOperacional(item.source))}</span>` : ""}
                                            ${item?.blocking ? "<span>Eleva para Mesa</span>" : ""}
                                        </div>
                                    </li>
                                `;
                            }).join("")}
                        </ul>
                    `
                    : '<p class="mesa-operacao-vazio">Sem red flags governadas ativas para este caso.</p>'}
            </section>
        `;
    };

    const obterResumoStatusOperacaoMesa = (collaboration) => {
        const abertas = Number(collaboration?.openPendencyCount || 0) || 0;
        const resolvidas = Number(collaboration?.resolvedPendencyCount || 0) || 0;

        if (abertas > 0) {
            return {
                icone: "assignment_late",
                rotulo: abertas === 1 ? "1 pendência aberta" : `${abertas} pendências abertas`,
                descricao: "Há itens da mesa aguardando retorno do campo neste laudo.",
            };
        }

        if (resolvidas > 0) {
            return {
                icone: "task_alt",
                rotulo: "Fluxo com resoluções recentes",
                descricao: "A mesa já recebeu retorno do campo e não há pendências abertas agora.",
            };
        }

        return {
            icone: "hourglass_top",
            rotulo: "Canal em triagem",
            descricao: "Sem pendencias abertas no momento. Acompanhe novas mensagens e chamados do laudo.",
        };
    };

    const adaptarReviewerCaseViewParaPainelMesa = (projection) => {
        const payload = (
            projection?.payload && typeof projection.payload === "object"
                ? projection.payload
                : projection
        );
        if (!payload || typeof payload !== "object") {
            return null;
        }
        return {
            codigo_hash: payload.codigo_hash,
            tipo_template: payload.tipo_template,
            setor_industrial: payload.setor_industrial,
            criado_em: payload.created_at,
            ultima_interacao_em: payload.last_interaction_at,
            tempo_em_campo_minutos: Number(payload.field_time_minutes || 0) || 0,
            resumo_pendencias: payload.summary_pending || {},
            revisao_por_bloco: payload.revisao_por_bloco || null,
            coverage_map: payload.coverage_map || null,
            historico_inspecao: payload.inspection_history || payload.historico_inspecao || null,
            verificacao_publica: payload.public_verification || payload.verificacao_publica || null,
            anexo_pack: payload.anexo_pack || null,
            emissao_oficial: payload.emissao_oficial || null,
            historico_refazer_inspetor: Array.isArray(payload.historico_refazer_inspetor)
                ? payload.historico_refazer_inspetor
                : [],
            memoria_operacional_familia: payload.memoria_operacional_familia || null,
            policy_summary: payload.policy_summary || null,
            collaboration: payload.collaboration || null,
            pendencias_abertas: Array.isArray(payload.open_pendencies) ? payload.open_pendencies : [],
            pendencias_resolvidas_recentes: Array.isArray(payload.recent_resolved_pendencies)
                ? payload.recent_resolved_pendencies
                : [],
            whispers_recentes: Array.isArray(payload.recent_whispers) ? payload.recent_whispers : []
        };
    };

    const renderizarPainelMesaOperacional = (pacote) => {
        medirSync("revisor.renderizarPainelMesaOperacional", () => {
            if (!els.mesaOperacaoPainel || !els.mesaOperacaoConteudo) return;

            if (!pacote || typeof pacote !== "object") {
                els.mesaOperacaoPainel.hidden = true;
                els.mesaOperacaoConteudo.innerHTML = "";
                renderizarPainelDocumentoTecnicoInline(null);
                sincronizarPlaceholderContextoMesa?.();
                return;
            }

            const resumoPendencias = pacote.resumo_pendencias || {};
            const ultimaInteracao = formatarDataHora(pacote.ultima_interacao_em);
            const criadoEm = formatarDataHora(pacote.criado_em);
            const collaboration = normalizarCollaborationSummary(pacote, {
                pendenciasAbertas: Number(resumoPendencias.abertas || 0) || 0,
                resolvedPendencyCount: Number(resumoPendencias.resolvidas || 0) || 0,
                whispersNaoLidos: Array.isArray(pacote.whispers_recentes) ? pacote.whispers_recentes.length : 0,
                recentWhisperCount: Array.isArray(pacote.whispers_recentes) ? pacote.whispers_recentes.length : 0
            });
            const totalWhispers = collaboration.recentWhisperCount;
            const statusOperacional = obterResumoStatusOperacaoMesa(collaboration);
            atualizarIndicadoresListaLaudo(state.laudoAtivoId, {
                collaborationSummary: pacote?.collaboration?.summary || {
                    open_pendency_count: collaboration.openPendencyCount,
                    resolved_pendency_count: collaboration.resolvedPendencyCount,
                    recent_whisper_count: collaboration.recentWhisperCount,
                    unread_whisper_count: collaboration.unreadWhisperCount,
                    recent_review_count: collaboration.recentReviewCount,
                    has_open_pendencies: collaboration.hasOpenPendencies,
                    has_recent_whispers: collaboration.hasRecentWhispers,
                    requires_reviewer_attention: collaboration.requiresReviewerAttention
                }
            });

            els.mesaOperacaoConteudo.innerHTML = `
                <div class="mesa-operacao-topo">
                    <div>
                        <h3>Operação da Mesa</h3>
                        <p>${escapeHtml(statusOperacional.descricao)}</p>
                    </div>
                    <span class="mesa-operacao-tag">
                        <span class="material-symbols-rounded" aria-hidden="true">${escapeHtml(statusOperacional.icone)}</span>
                        <span>${escapeHtml(statusOperacional.rotulo)}</span>
                    </span>
                </div>

                <div class="mesa-operacao-resumo">
                    <article class="mesa-operacao-kpi">
                        <span>Pendências abertas</span>
                        <strong>${escapeHtml(String(collaboration.openPendencyCount || 0))}</strong>
                        <small>Mensagens da mesa ainda em aberto para o inspetor.</small>
                    </article>
                    <article class="mesa-operacao-kpi">
                        <span>Resolvidas</span>
                        <strong>${escapeHtml(String(collaboration.resolvedPendencyCount || 0))}</strong>
                        <small>Itens já encerrados pelo fluxo em campo.</small>
                    </article>
                    <article class="mesa-operacao-kpi">
                        <span>Última interação</span>
                        <strong>${escapeHtml(ultimaInteracao)}</strong>
                        <small>Laudo iniciado em ${escapeHtml(criadoEm)}.</small>
                    </article>
                    <article class="mesa-operacao-kpi">
                        <span>Tempo em campo</span>
                        <strong>${escapeHtml(String(pacote.tempo_em_campo_minutos || 0))} min</strong>
                        <small>${escapeHtml(String(totalWhispers))} chamado(s) recente(s) no canal.</small>
                    </article>
                </div>

                <div class="mesa-operacao-insights">
                    ${renderizarGovernancaPolicyMesa(pacote.policy_summary)}
                    ${renderizarRevisaoPorBlocoMesa(pacote.revisao_por_bloco)}
                    ${renderizarCoverageMapMesa(pacote.coverage_map)}
                    ${renderizarHistoricoInspecaoMesa(pacote.historico_inspecao)}
                    ${renderizarVerificacaoPublicaMesa(pacote.verificacao_publica)}
                    ${renderizarAnexoPackMesa(pacote.anexo_pack)}
                    ${renderizarEmissaoOficialMesa(pacote.emissao_oficial)}
                    ${renderizarHistoricoRefazerInspetor(pacote.historico_refazer_inspetor)}
                    ${renderizarMemoriaOperacionalFamilia(pacote.memoria_operacional_familia)}
                </div>

                <div class="mesa-operacao-grid">
                    ${renderizarColunaOperacaoMesa({
                        titulo: "Pendências abertas",
                        itens: pacote.pendencias_abertas,
                        tipo: "aberta",
                        mensagemVazia: "Nenhuma pendência aberta neste momento.",
                        permitirResponder: true
                    })}
                    ${renderizarColunaOperacaoMesa({
                        titulo: "Resolvidas recentes",
                        itens: pacote.pendencias_resolvidas_recentes,
                        tipo: "resolvida",
                        mensagemVazia: "Ainda não há resoluções recentes para este laudo.",
                        permitirResponder: false
                    })}
                    ${renderizarColunaOperacaoMesa({
                        titulo: "Chamados recentes",
                        itens: pacote.whispers_recentes,
                        tipo: "whisper",
                        mensagemVazia: "Nenhum chamado recente registrado.",
                        permitirResponder: true
                    })}
                </div>
            `;

            els.mesaOperacaoPainel.hidden = false;
            renderizarPainelDocumentoTecnicoInline(pacote);
            sincronizarPlaceholderContextoMesa?.();
            snapshotDOM(`revisor:painel-mesa:${Number(state.laudoAtivoId || 0) || 0}`);
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 }, "render");
    };

    const atualizarPendenciaMesaOperacional = async (mensagemId, lida) => {
        return medirAsync("revisor.atualizarPendenciaMesaOperacional", async () => {
            const contexto = obterContextoLaudoAtivo();
            const laudoId = Number(contexto.laudoId || 0);
            const msgId = Number(mensagemId || 0);
            if (!Number.isFinite(laudoId) || laudoId <= 0 || !Number.isFinite(msgId) || msgId <= 0) {
                return;
            }

            try {
                const res = await fetch(`/revisao/api/laudo/${laudoId}/pendencias/${msgId}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-Token": tokenCsrf,
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    body: JSON.stringify({ lida: !!lida })
                });
                if (!res.ok) {
                    throw new Error(`Falha HTTP ${res.status}`);
                }

                const payload = await res.json();
                if (!contextoLaudoAindaValido(contexto)) {
                    return;
                }
                atualizarIndicadoresListaLaudo(laudoId, {
                    pendenciasAbertas: Number(payload?.pendencias_abertas || 0) || 0
                });
                await carregarPainelMesaOperacional({ forcar: true });
                showStatus(
                    lida ? "Pendência marcada como resolvida." : "Pendência reaberta.",
                    lida ? "task_alt" : "restart_alt"
                );
            } catch (erro) {
                showStatus("Erro ao atualizar pendência da mesa.", "error");
                console.error("[Tariel] Falha ao atualizar pendência da mesa:", erro);
            }
        }, { mensagemId: Number(mensagemId || 0) || 0, lida: !!lida });
    };

    const carregarPainelMesaOperacional = async ({ forcar = false } = {}) => {
        return medirAsync("revisor.carregarPainelMesaOperacional", async () => {
            const contexto = obterContextoLaudoAtivo();
            if (!els.mesaOperacaoPainel || !els.mesaOperacaoConteudo || !contexto.laudoId) return;

            if (
                !forcar
                && state.reviewerCaseViewPreferred
                && state.reviewerCaseViewLaudoId === contexto.laudoId
            ) {
                const pacotePreferencial = adaptarReviewerCaseViewParaPainelMesa(state.reviewerCaseViewAtivo);
                if (pacotePreferencial) {
                    renderizarPainelMesaOperacional(pacotePreferencial);
                    return;
                }
            }

            els.mesaOperacaoPainel.hidden = false;
            els.mesaOperacaoConteudo.innerHTML = `
                <div class="mesa-operacao-topo">
                    <div>
                        <h3>Operação da Mesa</h3>
                        <p>Carregando pendencias, resolucoes e chamados do laudo...</p>
                    </div>
                </div>
            `;

            try {
                const pacote = await obterPacoteMesaLaudo({ forcar });
                if (!contextoLaudoAindaValido(contexto)) {
                    return;
                }
                renderizarPainelMesaOperacional(pacote);
            } catch (erro) {
                if (ehAbortError(erro) || !contextoLaudoAindaValido(contexto)) {
                    return;
                }
                els.mesaOperacaoConteudo.innerHTML = `
                    <div class="mesa-operacao-topo">
                        <div>
                            <h3>Operação da Mesa</h3>
                            <p>Não foi possível carregar o pacote operacional da mesa agora.</p>
                        </div>
                    </div>
                `;
                console.error("[Tariel] Falha ao renderizar painel operacional da mesa:", erro);
            }
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0, forcar });
    };

    const STRUCTURED_DOCUMENT_STATUS_META = {
        filled: { label: "Preenchida", className: "filled" },
        partial: { label: "Parcial", className: "partial" },
        attention: { label: "Atencao", className: "attention" },
        empty: { label: "Vazia", className: "empty" }
    };

    const STRUCTURED_DOCUMENT_SECTION_TITLES = {
        identificacao: "Identificacao",
        caracterizacao_do_equipamento: "Caracterizacao",
        inspecao_visual: "Inspecao visual",
        dispositivos_e_acessorios: "Dispositivos e acessorios",
        dispositivos_e_controles: "Dispositivos e controles",
        documentacao_e_registros: "Documentacao e registros",
        nao_conformidades: "Nao conformidades",
        recomendacoes: "Recomendacoes",
        conclusao: "Conclusao"
    };

    const structuredValueHasContent = (value) => {
        if (value === null || value === undefined) return false;
        if (typeof value === "boolean" || typeof value === "number") return true;
        if (typeof value === "string") return value.trim().length > 0;
        if (Array.isArray(value)) return value.some((item) => structuredValueHasContent(item));
        if (typeof value === "object") return Object.values(value).some((item) => structuredValueHasContent(item));
        return Boolean(value);
    };

    const structuredNormalizeText = (value, maxLength = 180) => {
        if (value === null || value === undefined) return "";
        const raw = String(value).replace(/\s+/g, " ").trim();
        if (!raw) return "";
        if (raw.length <= maxLength) return raw;
        return `${raw.slice(0, Math.max(0, maxLength - 3)).trimEnd()}...`;
    };

    const structuredHumanizeKey = (value) => {
        const text = String(value || "").trim().replace(/_/g, " ");
        if (!text) return "";
        return text.replace(/\b\w/g, (match) => match.toUpperCase());
    };

    const structuredJoin = (parts, separator = " | ") => parts.filter(Boolean).join(separator);

    const structuredConclusionLabel = (value) => {
        const status = String(value || "").trim().toLowerCase();
        if (!status) return "";
        const labels = {
            ajuste: "Ajuste",
            aprovado: "Aprovado",
            conforme: "Conforme",
            reprovado: "Reprovado",
            nao_conforme: "Nao conforme",
            bloqueado: "Bloqueado",
            pendente: "Pendente"
        };
        return labels[status] || structuredHumanizeKey(status);
    };

    const structuredArtifactSummary = (value) => {
        if (!value || typeof value !== "object") return "";
        const parts = [];
        if (typeof value.disponivel === "boolean") {
            parts.push(value.disponivel ? "Disponivel" : "Ausente");
        }
        ["descricao", "referencias_texto", "observacao"].forEach((key) => {
            const text = structuredNormalizeText(value[key], 180);
            if (text) parts.push(text);
        });
        return structuredJoin(parts);
    };

    const structuredFlattenSectionEntries = (block) => {
        const entries = [];

        const visit = (value, path = []) => {
            if (!structuredValueHasContent(value)) return;

            if (Array.isArray(value)) {
                const text = value
                    .map((item) => structuredNormalizeText(item, 120))
                    .filter(Boolean)
                    .join(", ");
                if (text) {
                    entries.push({
                        label: structuredHumanizeKey(path[path.length - 1] || "itens"),
                        value: text
                    });
                }
                return;
            }

            if (value && typeof value === "object") {
                const isArtifact = ["disponivel", "descricao", "referencias_texto", "observacao"].some((key) =>
                    Object.prototype.hasOwnProperty.call(value, key)
                );
                if (isArtifact) {
                    const text = structuredArtifactSummary(value);
                    if (text) {
                        entries.push({
                            label: structuredHumanizeKey(path[path.length - 1] || "item"),
                            value: text
                        });
                    }
                    return;
                }

                Object.entries(value).forEach(([key, nestedValue]) => {
                    visit(nestedValue, [...path, key]);
                });
                return;
            }

            if (typeof value === "boolean") {
                entries.push({
                    label: structuredHumanizeKey(path[path.length - 1] || "campo"),
                    value: value ? "Sim" : "Nao"
                });
                return;
            }

            const text = structuredNormalizeText(value, 180);
            if (!text) return;
            entries.push({
                label: structuredHumanizeKey(path[path.length - 1] || "campo"),
                value: text
            });
        };

        visit(block, []);
        return entries;
    };

    const structuredResolveSectionStatus = (key, block, entryCount) => {
        if (!entryCount) return "empty";
        if (key === "nao_conformidades" && block?.ha_nao_conformidades === true) return "attention";
        if (key === "conclusao") {
            const status = String(block?.status || "").trim().toLowerCase();
            if (["ajuste", "reprovado", "nao_conforme", "bloqueado"].includes(status)) {
                return "attention";
            }
        }
        if (entryCount <= 2) return "partial";
        return "filled";
    };

    const structuredSectionSummary = (key, block, entries) => {
        if (key === "nao_conformidades" && block?.ha_nao_conformidades === false) {
            return "Sem nao conformidades estruturadas.";
        }
        if (key === "conclusao") {
            return structuredJoin([
                structuredConclusionLabel(block?.status),
                structuredNormalizeText(block?.conclusao_tecnica, 160)
            ]);
        }
        if (key === "recomendacoes") {
            return structuredNormalizeText(block?.texto, 180);
        }
        if (key === "identificacao") {
            const identificador = Object.entries(block || {}).find(([entryKey, entryValue]) =>
                String(entryKey || "").startsWith("identificacao_") && structuredValueHasContent(entryValue)
            );
            return structuredJoin([
                structuredNormalizeText(identificador?.[1], 120),
                structuredNormalizeText(block?.localizacao, 120),
                structuredNormalizeText(block?.tag_patrimonial, 80)
            ]);
        }
        if (!Array.isArray(entries) || !entries.length) return "";
        return structuredJoin(
            entries.slice(0, 2).map((entry) => `${entry.label}: ${entry.value}`)
        );
    };

    const buildCanonicalReviewDocument = (data) => {
        if (!data || typeof data !== "object") return null;
        if (String(data.schema_type || "").trim().toLowerCase() !== "laudo_output") return null;

        const orderedSectionKeys = [
            "identificacao",
            "caracterizacao_do_equipamento",
            "inspecao_visual",
            "dispositivos_e_acessorios",
            "dispositivos_e_controles",
            "documentacao_e_registros",
            "nao_conformidades",
            "recomendacoes",
            "conclusao"
        ];

        const sections = orderedSectionKeys
            .filter((key) => data[key] && typeof data[key] === "object")
            .map((key) => {
                const block = data[key];
                const entries = structuredFlattenSectionEntries(block);
                return {
                    key,
                    title: STRUCTURED_DOCUMENT_SECTION_TITLES[key] || structuredHumanizeKey(key),
                    status: structuredResolveSectionStatus(key, block, entries.length),
                    summary: structuredSectionSummary(key, block, entries),
                    entries
                };
            });

        return {
            familyKey: String(data.family_key || "").trim(),
            summary: structuredNormalizeText(
                data.resumo_executivo
                    || data?.conclusao?.conclusao_tecnica
                    || data?.conclusao?.justificativa,
                220
            ),
            reviewNotes: structuredNormalizeText(
                data?.mesa_review?.pendencias_resolvidas_texto
                    || data?.mesa_review?.observacoes_mesa
                    || data?.mesa_review?.bloqueios_texto,
                220
            ),
            sections
        };
    };

    const renderStructuredDocumentChip = (status) => {
        const meta = STRUCTURED_DOCUMENT_STATUS_META[String(status || "").trim().toLowerCase()] || STRUCTURED_DOCUMENT_STATUS_META.empty;
        return `<span class="structured-document-chip ${escapeHtml(meta.className)}">${escapeHtml(meta.label)}</span>`;
    };

    const renderStructuredDocumentOverview = (documento) => {
        if (!documento || typeof documento !== "object") return "";
        const sections = Array.isArray(documento.sections) ? documento.sections : [];
        if (!sections.length) return "";

        return `
            <section class="structured-document-overview">
                <header class="structured-document-overview-topo">
                    <div>
                        <span class="structured-document-kicker">
                            ${escapeHtml(String(documento.family_label || documento.family_key || documento.schema_type || "laudo_output"))}
                        </span>
                            <h3>Leitura técnica organizada</h3>
                            <p>${escapeHtml(String(documento.summary || "Documento organizado em blocos técnicos para leitura da mesa."))}</p>
                    </div>
                    ${documento.family_key ? `<span class="structured-document-family-key">${escapeHtml(String(documento.family_key))}</span>` : ""}
                </header>
                ${documento.review_notes ? `<p class="structured-document-review-notes">Mesa: ${escapeHtml(String(documento.review_notes))}</p>` : ""}
                <div class="structured-document-grid">
                    ${sections.map((section) => `
                        <article class="structured-document-card">
                            <div class="structured-document-card-topo">
                                <div>
                                    <h4>${escapeHtml(String(section.title || structuredHumanizeKey(section.key || "secao")))}</h4>
                                    <p>${escapeHtml(String(section.summary || "Sem destaque adicional nesta secao."))}</p>
                                </div>
                                ${renderStructuredDocumentChip(section.status)}
                            </div>
                            <div class="structured-document-card-meta">
                                <span>${escapeHtml(String(section.filled_fields || 0))}/${escapeHtml(String(section.total_fields || 0))} campos preenchidos</span>
                                ${section.diff_short ? `<span>${escapeHtml(String(section.diff_short))}</span>` : "<span>Sem delta recente da mesa.</span>"}
                            </div>
                        </article>
                    `).join("")}
                </div>
            </section>
        `;
    };

    const renderStructuredDocumentInlinePanel = (documento) => {
        if (!documento || typeof documento !== "object") return "";
        const sections = Array.isArray(documento.sections) ? documento.sections : [];
        if (!sections.length) return "";

        return `
            <section class="view-structured-document-panel">
                <header class="view-structured-document-head">
                    <div>
                        <span class="view-structured-document-kicker">
                            ${escapeHtml(String(documento.family_label || documento.familyKey || documento.family_key || documento.schema_type || "laudo_output"))}
                        </span>
                        <h3>Leitura técnica do laudo</h3>
                        <p>${escapeHtml(String(documento.summary || "Painel por seção do laudo para apoiar a revisão."))}</p>
                    </div>
                    ${(documento.familyKey || documento.family_key) ? `<span class="view-structured-document-family-key">${escapeHtml(String(documento.familyKey || documento.family_key))}</span>` : ""}
                </header>
                ${(documento.reviewNotes || documento.review_notes) ? `
                    <p class="view-structured-document-note">
                        Mesa: ${escapeHtml(String(documento.reviewNotes || documento.review_notes))}
                    </p>
                ` : ""}
                <div class="view-structured-document-grid">
                    ${sections.map((section) => `
                        <article class="view-structured-document-card">
                            <div class="view-structured-document-card-topo">
                                <div>
                                    <h4>${escapeHtml(String(section.title || structuredHumanizeKey(section.key || "secao")))}</h4>
                                    <p>${escapeHtml(String(section.summary || "Sem destaque adicional nesta secao."))}</p>
                                </div>
                                ${renderStructuredDocumentChip(section.status)}
                            </div>
                            <div class="view-structured-document-card-meta">
                                <span>${escapeHtml(String(section.filled_fields ?? section.entries?.length ?? 0))}/${escapeHtml(String(section.total_fields ?? section.entries?.length ?? 0))} campos-chave</span>
                                ${section.diff_short ? `<span>${escapeHtml(String(section.diff_short))}</span>` : "<span>Sem observacao curta adicional.</span>"}
                            </div>
                        </article>
                    `).join("")}
                </div>
            </section>
        `;
    };

    const renderizarPainelDocumentoTecnicoInline = (pacote = null) => {
        if (!els.viewStructuredDocument) return;
        if (!state.laudoAtivoId) {
            els.viewStructuredDocument.hidden = true;
            els.viewStructuredDocument.innerHTML = "";
            return;
        }

        const documento = (
            pacote?.documento_estruturado
            || state.pacoteMesaAtivo?.documento_estruturado
            || buildCanonicalReviewDocument(state.jsonEstruturadoAtivo)
            || null
        );
        const html = renderStructuredDocumentInlinePanel(documento);

        if (!html) {
            els.viewStructuredDocument.hidden = true;
            els.viewStructuredDocument.innerHTML = "";
            return;
        }

        els.viewStructuredDocument.hidden = false;
        els.viewStructuredDocument.innerHTML = html;
    };

    const renderListaPacote = (itens, mensagemVazia) => {
        if (!Array.isArray(itens) || !itens.length) {
            return `<li>${escapeHtml(mensagemVazia || "Sem registros no momento.")}</li>`;
        }

        return itens.slice(0, 8).map((item) => {
            const anexos = Array.isArray(item?.anexos) ? item.anexos.map(normalizarAnexoMensagem).filter(Boolean) : [];
            const texto = resumoMensagem(item?.texto || (anexos.length ? "Anexo enviado" : ""));
            const data = formatarDataHora(item?.criado_em);
            const tipo = String(item?.tipo || "mensagem");
            const status = item?.resolvida_em
                ? `Resolvida em ${formatarDataHora(item.resolvida_em)}`
                : "Aberta";
            const infoAnexos = anexos.length
                ? `<span class="meta">Anexos: ${escapeHtml(anexos.map((anexo) => anexo.nome).join(", "))}</span>`
                : "";

            return `
                <li>
                    <strong>#${escapeHtml(String(item?.id || "-"))} · ${escapeHtml(tipo)}</strong><br>
                    ${escapeHtml(texto)}
                    <span class="meta">${escapeHtml(data)} · ${escapeHtml(status)}</span>
                    ${infoAnexos}
                </li>
            `;
        }).join("");
    };

    const renderizarModalPacote = (pacote) => {
        if (!pacote || typeof pacote !== "object") {
            els.modalPacoteConteudo.innerHTML = "<p>Pacote técnico indisponível para este laudo.</p>";
            return;
        }

        const resumoMensagens = pacote.resumo_mensagens || {};
        const resumoEvidencias = pacote.resumo_evidencias || {};
        const resumoPendencias = pacote.resumo_pendencias || {};
        const hashCurto = String(pacote.codigo_hash || "").slice(-6) || "-";
        const documentoEstruturado = pacote.documento_estruturado || null;

        els.modalPacoteConteudo.innerHTML = `
            <div class="pacote-meta">
                <strong>Laudo #${escapeHtml(hashCurto)}</strong> ·
                Modelo ${escapeHtml(String(pacote.tipo_template || "").toUpperCase())} ·
                Setor ${escapeHtml(String(pacote.setor_industrial || "-"))} ·
                Última interação: ${escapeHtml(formatarDataHora(pacote.ultima_interacao_em))}
            </div>

            <div class="pacote-grid">
                <section class="pacote-card">
                    <h4>Mensagens</h4>
                    <div class="pacote-kpi"><span>Total</span><strong>${escapeHtml(String(resumoMensagens.total || 0))}</strong></div>
                    <div class="pacote-kpi"><span>Inspetor</span><span>${escapeHtml(String(resumoMensagens.inspetor || 0))}</span></div>
                    <div class="pacote-kpi"><span>Assistente</span><span>${escapeHtml(String(resumoMensagens.ia || 0))}</span></div>
                    <div class="pacote-kpi"><span>Mesa</span><span>${escapeHtml(String(resumoMensagens.mesa || 0))}</span></div>
                </section>

                <section class="pacote-card">
                    <h4>Evidências</h4>
                    <div class="pacote-kpi"><span>Total</span><strong>${escapeHtml(String(resumoEvidencias.total || 0))}</strong></div>
                    <div class="pacote-kpi"><span>Textuais</span><span>${escapeHtml(String(resumoEvidencias.textuais || 0))}</span></div>
                    <div class="pacote-kpi"><span>Fotos</span><span>${escapeHtml(String(resumoEvidencias.fotos || 0))}</span></div>
                    <div class="pacote-kpi"><span>Documentos</span><span>${escapeHtml(String(resumoEvidencias.documentos || 0))}</span></div>
                </section>

                <section class="pacote-card">
                    <h4>Pendências</h4>
                    <div class="pacote-kpi"><span>Total</span><strong>${escapeHtml(String(resumoPendencias.total || 0))}</strong></div>
                    <div class="pacote-kpi"><span>Abertas</span><span>${escapeHtml(String(resumoPendencias.abertas || 0))}</span></div>
                    <div class="pacote-kpi"><span>Resolvidas</span><span>${escapeHtml(String(resumoPendencias.resolvidas || 0))}</span></div>
                    <div class="pacote-kpi"><span>Tempo em campo</span><span>${escapeHtml(String(pacote.tempo_em_campo_minutos || 0))} min</span></div>
                </section>
            </div>

            ${renderStructuredDocumentOverview(documentoEstruturado)}

            <h3 style="margin:0 0 10px; color:var(--cor-secundaria);">Pendências Abertas</h3>
            <ul class="pacote-lista">${renderListaPacote(pacote.pendencias_abertas, "Sem pendências abertas.")}</ul>

            <h3 style="margin:18px 0 10px; color:var(--cor-secundaria);">Chamados Recentes</h3>
            <ul class="pacote-lista">${renderListaPacote(pacote.whispers_recentes, "Sem chamados registrados.")}</ul>
        `;
    };

    const abrirResumoPacoteMesa = async () => {
        return medirAsync("revisor.abrirResumoPacoteMesa", async () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return;
            try {
                showStatus("Carregando pacote técnico...", "sync");
                const pacote = await obterPacoteMesaLaudo({ forcar: true });
                if (!contextoLaudoAindaValido(contexto) || !pacote) {
                    return;
                }
                renderizarModalPacote(pacote);
                openModal(els.modalPacote, els.btnFecharPacote);
                snapshotDOM(`revisor:modal-pacote:${contexto.laudoId}`);
            } catch (erro) {
                if (ehAbortError(erro) || !contextoLaudoAindaValido(contexto)) {
                    return;
                }
                showStatus("Erro ao carregar pacote técnico.", "error");
                console.error("[Tariel] Falha ao carregar pacote técnico:", erro);
            }
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const baixarPacoteMesaJson = async () => {
        return medirAsync("revisor.baixarPacoteMesaJson", async () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return;
            try {
                const pacote = await obterPacoteMesaLaudo({ forcar: false });
                if (!pacote) return;
                const hashCurto = String(pacote.codigo_hash || state.laudoAtivoId).slice(-6);
                downloadJson(`pacote_mesa_${hashCurto}.json`, pacote);
                showStatus("Dados do caso baixados.", "download_done");
            } catch (erro) {
                if (ehAbortError(erro) || !contextoLaudoAindaValido(contexto)) {
                    return;
                }
                showStatus("Erro ao baixar pacote de dados.", "error");
                console.error("[Tariel] Falha ao baixar pacote de dados:", erro);
            }
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const baixarPacoteMesaPdf = () => {
        medirSync("revisor.baixarPacoteMesaPdf", () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return;
            if (!userCapabilityEnabled("reviewer_decision")) {
                showStatus(tenantCapabilityReason("reviewer_decision"), "warning");
                return;
            }
            const url = `/revisao/api/laudo/${contexto.laudoId}/pacote/exportar-pdf`;
            const link = document.createElement("a");
            link.href = url;
            link.target = "_blank";
            link.rel = "noopener";
            document.body.appendChild(link);
            link.click();
            link.remove();
            showStatus("Gerando PDF do pacote...", "picture_as_pdf");
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const baixarPacoteMesaOficial = () => {
        medirSync("revisor.baixarPacoteMesaOficial", () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return;
            if (!userCapabilityEnabled("reviewer_issue")) {
                showStatus(tenantCapabilityReason("reviewer_issue"), "warning");
                return;
            }
            const url = `/revisao/api/laudo/${contexto.laudoId}/pacote/exportar-oficial`;
            const link = document.createElement("a");
            link.href = url;
            link.target = "_blank";
            link.rel = "noopener";
            document.body.appendChild(link);
            link.click();
            link.remove();
            showStatus("Gerando ZIP oficial...", "folder_zip");
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const baixarEmissaoOficialCongelada = () => {
        medirSync("revisor.baixarEmissaoOficialCongelada", () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return;
            if (!userCapabilityEnabled("reviewer_issue")) {
                showStatus(tenantCapabilityReason("reviewer_issue"), "warning");
                return;
            }
            const url = `/revisao/api/laudo/${contexto.laudoId}/emissao-oficial/download`;
            const link = document.createElement("a");
            link.href = url;
            link.target = "_blank";
            link.rel = "noopener";
            document.body.appendChild(link);
            link.click();
            link.remove();
            showStatus("Baixando bundle oficial congelado...", "folder_zip");
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const emitirOficialmenteMesa = async ({
        signatoryId,
        signatoryName,
        expectedCurrentIssueId,
        expectedCurrentIssueNumber
    } = {}) => {
        return medirAsync("revisor.emitirOficialmenteMesa", async () => {
            const contexto = obterContextoLaudoAtivo();
            if (!contexto.laudoId) return null;
            if (!userCapabilityEnabled("reviewer_issue")) {
                showStatus(tenantCapabilityReason("reviewer_issue"), "warning");
                return null;
            }
            const response = await fetch(`/revisao/api/laudo/${contexto.laudoId}/emissao-oficial`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-Token": tokenCsrf,
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: JSON.stringify({
                    signatory_id: Number(signatoryId || 0) || null,
                    expected_current_issue_id: Number(expectedCurrentIssueId || 0) || null,
                    expected_current_issue_number: String(expectedCurrentIssueNumber || "").trim() || null
                })
            });
            const payload = await response.json().catch(() => null);
            if (!response.ok) {
                throw new Error(payload?.detail || `Falha HTTP ${response.status}`);
            }
            const rotulo = signatoryName ? ` com ${signatoryName}` : "";
            const supersededIssueNumber = String(payload?.superseded_issue_number || "").trim();
            showStatus(
                payload?.idempotent_replay
                    ? (
                        supersededIssueNumber
                            ? `Reemissão oficial já existia${rotulo}, substituindo ${supersededIssueNumber}.`
                            : `Emissão oficial já existia${rotulo}.`
                    )
                    : (
                        payload?.reissued
                            ? `Reemissão oficial registrada${rotulo}, substituindo ${supersededIssueNumber || "a emissão anterior"}.`
                            : `Emissão oficial registrada${rotulo}.`
                    ),
                "task_alt"
            );
            return payload;
        }, { laudoId: Number(state.laudoAtivoId || 0) || 0 });
    };

    const renderizarModalRelatorio = () => {
        if (!state.jsonEstruturadoAtivo) {
            els.modalConteudo.innerHTML = "<p>Sem dados estruturados.</p>";
            return;
        }

        const data = state.jsonEstruturadoAtivo;
        const documentoCanonico = buildCanonicalReviewDocument(data);
        if (documentoCanonico) {
            const secoes = Array.isArray(documentoCanonico.sections) ? documentoCanonico.sections : [];
            els.modalConteudo.innerHTML = `
                <div class="relatorio-canonical-header">
                    <div>
                        <span class="relatorio-canonical-kicker">
                            ${escapeHtml(documentoCanonico.familyKey || "laudo_output")}
                        </span>
                        <h3>Seções organizadas do laudo</h3>
                        <p>Leitura por seção do conteúdo estruturado para revisão técnica.</p>
                    </div>
                    <span class="relatorio-canonical-badge">
                        ${escapeHtml(String(secoes.length))} secao(oes)
                    </span>
                </div>
                ${documentoCanonico.summary ? `
                    <div class="relatorio-resumo">
                        <strong>Resumo executivo:</strong><br>
                        ${nl2br(documentoCanonico.summary)}
                    </div>
                ` : ""}
                ${documentoCanonico.reviewNotes ? `
                    <div class="relatorio-canonical-note">
                        <strong>Mesa:</strong> ${escapeHtml(documentoCanonico.reviewNotes)}
                    </div>
                ` : ""}
                <div class="relatorio-canonical-grid">
                    ${secoes.length ? secoes.map((section) => `
                        <article class="relatorio-section-card">
                            <div class="relatorio-section-topo">
                                <div>
                                    <h3>${escapeHtml(String(section.title || structuredHumanizeKey(section.key || "secao")))}</h3>
                                    <p>${escapeHtml(String(section.summary || "Sem destaque adicional nesta secao."))}</p>
                                </div>
                                ${renderStructuredDocumentChip(section.status)}
                            </div>
                            ${Array.isArray(section.entries) && section.entries.length ? `
                                <div class="relatorio-section-entries">
                                    ${section.entries.slice(0, 8).map((entry) => `
                                        <div class="relatorio-section-entry">
                                            <span>${escapeHtml(String(entry.label || "Campo"))}</span>
                                            <strong>${escapeHtml(String(entry.value || "-"))}</strong>
                                        </div>
                                    `).join("")}
                                    ${section.entries.length > 8 ? `<p class="relatorio-section-more">+${escapeHtml(String(section.entries.length - 8))} campo(s) adicionais neste bloco.</p>` : ""}
                                </div>
                            ` : `<p class="relatorio-section-empty">Sem dados estruturados nesta secao.</p>`}
                        </article>
                    `).join("") : `<p class="relatorio-section-empty">Nenhum bloco tecnico disponivel.</p>`}
                </div>
            `;
            return;
        }

        let html = "";

        if (data.resumo_executivo) {
            html += `
                <div class="relatorio-resumo">
                    <strong>Resumo do assistente:</strong><br>
                    ${nl2br(data.resumo_executivo)}
                </div>
            `;
        }

        const secoes = [
            { k: "seguranca_estrutural", t: "SEGURANÇA ESTRUTURAL" },
            { k: "cmar", t: "CMAR" }
        ];

        secoes.forEach((secao) => {
            const bloco = data[secao.k];
            if (!bloco) return;

            html += `<h3 style="color:var(--cor-secundaria); margin:20px 0 0;">${escapeHtml(secao.t)}</h3>`;
            html += `
                <table class="tabela-relatorio">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Cond</th>
                            <th>Obs</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            Object.entries(bloco).forEach(([chave, valor]) => {
                if (!valor || !valor.condicao) return;
                const cond = String(valor.condicao).toUpperCase();
                const klass = cond === "C" ? "cond-C" : cond === "NC" ? "cond-NC" : "";

                html += `
                    <tr>
                        <td>${escapeHtml(chave.replace(/_/g, " ").toUpperCase())}</td>
                        <td class="${klass}">${escapeHtml(valor.condicao)}</td>
                        <td>${escapeHtml(valor.observacao || "-")}</td>
                    </tr>
                `;
            });

            html += `</tbody></table>`;
        });

        els.modalConteudo.innerHTML = html || "<p>Sem conteúdo estruturado disponível.</p>";
    };

    Object.assign(NS, {
        renderizarItemOperacaoMesa,
        renderizarColunaOperacaoMesa,
        obterResumoStatusOperacaoMesa,
        renderizarPainelMesaOperacional,
        atualizarPendenciaMesaOperacional,
        carregarPainelMesaOperacional,
        renderListaPacote,
        renderizarModalPacote,
        abrirResumoPacoteMesa,
        baixarPacoteMesaJson,
        baixarPacoteMesaPdf,
        baixarPacoteMesaOficial,
        baixarEmissaoOficialCongelada,
        emitirOficialmenteMesa,
        renderizarModalRelatorio,
        renderizarPainelDocumentoTecnicoInline
    });
})();
